import React, {Component} from 'react';
// import axios from 'axios';

class Login extends Component {
    state={};  
    render() {
        
        return(

        <div>
            <h4>Login Page</h4>
        </div>
        );
    }
}

export default Login;