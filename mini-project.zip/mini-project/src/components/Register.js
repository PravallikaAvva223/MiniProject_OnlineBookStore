import React, {Component} from 'react';
// import axios from 'axios';

class Register extends Component {
    state={};  
    render() {
        
        return(

        <div>
            <h4>Registration  Page</h4>
        </div>
        );
    }
}

export default Register;