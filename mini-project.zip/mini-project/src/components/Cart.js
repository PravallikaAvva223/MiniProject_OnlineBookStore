import React, {Component} from 'react';
// import axios from 'axios';

class Cart extends Component {
    state={};  
    render() {
        
        return(

        <div>
            <h4> Add to Cart </h4>
        </div>
        );
    }
}

export default Cart;